$('#check').on('click',function  () {
	// body...

	$('#item').css('text-decoration','line-through');


})